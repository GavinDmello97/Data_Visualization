# Example 1
## Histogram for Normal Distribution
A histogram is an approximate representation of the distribution of numerical data ([wiki](https://en.wikipedia.org/wiki/Histogram)).

<img src="../images/Example1.png"/>