# TreeMap

## Using Stratify, Hierarchy, and Tree Layouts

<ol>
<li>
Example 1 Simple Treemap<br>
<img src="imgs/Example_1.png" width="250px">
</li>
<li>
Example 2 US Population Treemap
<br><img src="imgs/Example_2.png" width="250px">
</li>
<li>
Example 3 - Using Echarts
<br><img src="imgs/Example_3.png" width="250px">
</li>
<li>
Example 4 - D3 Circle Pack
<br><img src="imgs/Example_4.png" width="250px">
<ul>
<li>
Circle Pack
</li>
<li>
Circle Pack adding labels
</li>
</ul>
</li>
</ol>
 
