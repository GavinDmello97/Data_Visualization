# Exercise 01: Line Chart

### Use the data_sample.csv

<hr>
<b> Use Scale to d3.scaleLinear and d3.scaleTime()
refer to  <br>
<a href="https://github.com/umassdgithub/Fall2021-Week-5-Monday/blob/master/Example_Mon%205.6/index.html">

umassdgithub/Fall2021-Week-5-Monday/.../Styling_plot.html 
</a>
</b>
<hr>
<ol>
<li>Use d3.line() generator to calculate attribute "d" for "path" element</li>
<li>Make use of scaleLinear and scaleTime function</li>
<li>Give a different color foreach line</li>
</ol>
<br>

Use transition and styling to make the chart look nicer.


#### SVG viewBox(0 0 1000 800)
